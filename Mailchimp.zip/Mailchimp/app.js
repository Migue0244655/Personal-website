const express = require("express");
const app = express();
app.use(express.json());
app.use(express.urlencoded({extended : true }));
app.use(express.static("public"));
app.engine("ejs", require("ejs").renderFile);
app.set("view engine", "ejs");
const https = require("https");

const apiKey = "d9531bb4fd1a8459fc91e0f883fd2bd0-us21";
const list_id = "47e4de2a89";
const url = "https://us21.api.mailchimp.com/3.0/lists/" + list_id;
const options = {
    method: "POST",
    auth: "0244655@up.edu.mx:" + apiKey
}

app.get('/', (req, res) =>{
    res.sendFile(__dirname + "/signup.html");
});

app.post('/',(req, res) =>{
    const fName = req.body.fName;
    const lName = req.body.lName;
    const email = req.body.email;

    var data = {
        members: [
            {
                email_address: email,
                status: "subscribed",
                merge_fields: {
                    FNAME: fName,
                    LNAME: lName
                }
            }
        ]
    }

    var mailRequest = https.request(url, options, (response) => {
        if(response.statusCode === 200) {
            response.on("data", (data) => {
                var jsonResp = JSON.parse(data);
                if(jsonResp["error_count"] === 0) {
                    res.sendFile(__dirname +"/success.html");
                } else {
                    res.sendFile(__dirname +"/failure.html");
                    console.log(jsonResp.errors[0]["error_code"]);
                    console.log(jsonResp.errors[0]["error"]);
                }
            }).on("error", (e) => {
                res.sendFile(__dirname +"/failure.html");
            });
        } else {
            res.sendFile(__dirname +"/failure.html");
        }
    });
    var jsonData = JSON.stringify(data);
    mailRequest.write(jsonData);
    mailRequest.end();
});

app.get("/failure", (req, res) => {
    res.redirect("/");
});

app.get("/success", (req, res) => {
    res.redirect("/");
});

app.listen(3000, () => {
    console.log("Listening on port 3000");
});